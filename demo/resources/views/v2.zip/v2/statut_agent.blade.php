<!doctype html>
<html lang="en">
  
<head><meta charset="windows-1252">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    <link rel="short icon" href="{{asset('collov2/assets/images/icon.png')}}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <title>COLLABORATIS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
<link href="{{asset('v2/main.css')}}" rel="stylesheet"></head>
<body>   
@include('v3.modal')
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
            <!--header -->
            @include('v2.header_dg')
            <!-- end header -->

        <div class="app-main">
                <!-- side bar -->
                @include('v2.side_bar_dg')
    
                <!-- end side bar -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                       <!-- perfo -->
                               

                                

                       <!-- end perfo --> 
                        
                        
                        <!-- perfo de mes direc -->
                       

                         <!-- end perfo de mes direct -->
                        
                        <!-- section -->

                        <div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                
                                    <div class="card-header" style="font-family: 'Montserrat', sans-serif; font-size : 12 px; font-weight : bolder; color : black;">Statut des agents
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-responsive-xl ml-4">
                                            <thead>
                                            <tr>
                                                <th class="table-label">Nom et prénom</th>
                                                <th class="table-label">Statut</th>
                                                <th class="table-label" style="text-align : center;">Dernière connexion</th>
                                               
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($userAgents as $user)
                                            
                                            
                                               <tr>
                                                   <td class="d-flex align-items-center">
                                                       @if($user->photo == NULL)
                                                       <span class="rounded-circle" style="border: 1px solid #3f6ad8; background: white; color:#2C365E; font-weight:bold; font-size:18px; padding:10px; text-shadow: 1px 1px 2px white;">{{substr($user->prenom, 0,1)}} {{substr($user->nom, 0,1)}}</span>
                                                       @else
                        						      	<img width="50" height="50" class="rounded-circle" src="{{ url('images/', $user->photo) }}" alt="">
                        						       @endif
                        						      	<div class="pl-3 email" >
                        						      		<span class="text-nice" style="text-align : left;">{{$user->prenom}} {{$user->nom}}</span>
                        						      		<?php $agentss = DB::table('agents')->where('user_id', $user->id)->get() ?>
                        						      		@foreach($agentss as $a)
                        						      		<?php $directions = DB::table('directions')->where('id', $a->direction_id)->get() ?>
                        						      		@foreach($directions as $d)
                        						      		<span class="text-nice">{{$d->nom_direction}}</span>
                        						      		@endforeach
                        						      		@endforeach
                        						      	</div>
                                                   </td>
                                                  
                                                    <td class="">
                                                        @if($user->isOnline())
                                                      <i class='fas fa-dot-circle' style='font-size:24px;color:green'></i>
                                                        @else
                                                       <i class='fas fa-dot-circle' style='font-size:24px;color:red'></i>
                                                        
                                                        
                                                       @endif
                                                    </td>
                                                
                                                @if(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400) == 0)
                                                  @if(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 3600) > 0)

                                                @if(intval(abs(strtotime("now") - strtotime($user->last_online_at))/3600) == 1) 
                                                <td class="text-nice">
                                                  il y'a {{intval(abs(strtotime("now") - strtotime($user->last_online_at))/3600)}} heure
                                                </td>
                                                @else
                                                <td class="text-nice">
                                                il y'a {{intval(abs(strtotime("now") - strtotime($user->last_online_at))/3600)}} heures
                                                </td>
                                                @endif
                                                  
                                                  @else(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 3600) == 0)
                                                  <td class="text-nice">il y'a {{intval(abs(strtotime("now") - strtotime($user->last_online_at))/60)}} minutes</td>
                                                  @endif
                                                @elseif(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400) == 1)
                                                <td class="text-nice">Hier à {{strftime("%H:%M", strtotime($user->last_online_at))}}</td>
                                                @elseif(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400) >= 2 && intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400) <= 27)
                                                <td class="text-nice">il y'a {{intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400)}} jours </td>
                                                @else(intval(abs(strtotime("now") - strtotime($user->last_online_at))/ 86400) > 27)
                                                <td class="text-nice">Le {{strftime("%d/%m/%Y", strtotime($user->last_online_at))}}</td>
                                                @endif
                                                
                                                <?php $agents = DB::table('agents')->where("user_id",$user->id)->get(); ?>
                                                @foreach($agents as $agent)
                                               <?php $actio = DB::table('modeles')->where("res_dir",$agent->id)->orderBy('updated_at','DESC')->paginate(1); ?>
                                               
                                            @endforeach  
                                            
                                            <?php $agentts = DB::table('agents')->where("user_id",$user->id)->get(); ?>
                                                @foreach($agentts as $agentt)
                                               <?php $actiot = DB::table('tache_modeles')->where("res_dir",$agentt->id)->orderBy('updated_at','DESC')->paginate(1); ?>
                                                
                                            @endforeach  
                                                
                                                
                                               <?php $actionsf = DB::table('actions')->where('agent_id',$user->id)->orWhereNull('agent_id')->orderBy('updated_at','DESC')->paginate(1); ?>
                                                 @foreach($actionsf as $actionf)
                                                
                                                
                                               
                                               
                                                </tr>
                                                @endforeach
                                           
                                                 @endforeach
                                           
                                        </tbody>
                                        </table>
                                    </div>
                                    <div class="d-block text-center card-footer">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>

                        

                        
                    </div>
                    <style>

.img {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center; }
  
  .table tbody td .email span {
    display: block; }
    .table tbody td .email span:last-child {
      font-size: 12px;}
      
  
  
  
  
  
  
  
  
  
.text-nice{
    font-family: 'poppins', sans-serif;
    font-size : 14px;
    text-align : center;
}


.flip-box {
background-color: transparent;
width: 25px;
height: 25px;
border: 1px solid #f1f1f1;
perspective: 1000px;
}

.flip-box-inner {
position: relative;
width: 100%;
height: 100%;
text-align: center;
transition: transform 0.8s;
transform-style: preserve-3d;
}

.flip-box:hover .flip-box-inner {
transform: rotateY(180deg);
}

.flip-box-front, .flip-box-back {
position: absolute;
width: 100%;
height: 100%;
-webkit-backface-visibility: hidden;
backface-visibility: hidden;
}

.flip-box-front {

color: black;
}

.flip-box-back {
background-color: white;
color: green;
text-align: center;
transform: rotateY(180deg);
}
</style> 

<style>

/* The Modal (background) */
.modal {
display: none; /* Hidden by default */
margin-left: 90px;
margin-top: 150px;
width: 250px; /* Full width */
height: 80px; /* Full height */


}

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding: 20px;
border: 1px solid #888;
width: 100%;
height: 100%;
}

/* The Close Button */
.close {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
}

.close:hover,
.close:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script>
$(document).ready(function(){

@foreach($actions as $suivi)

$("#loginVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);  
}
});
}

});

$("#loginnVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginnVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',  
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);
}
});
}

});
@endforeach
});
</script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

<script>
$(document).ready(function(){

@foreach($actions as $suivi)

$("#loginVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);  
}
});
}

});

$("#loginnVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginnVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',  
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);
}
});
}

});
@endforeach
});
</script>
  
<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>
 
                        <!-- end section -->

                            <div class="app-wrapper-footer">
                                <div class="app-footer">
                                    <div class="app-footer__inner">
                                        <div class="app-footer-left">
                                            <ul class="nav">
                                                <li class="nav-item">
                                                    <a href="javascript:void(0);" class="nav-link">
                                                        © Collaboratis 2021 | Made with passion by ILLIMITIS
                                                    </a>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>   
                    
                </div>
                <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        </div>
    </div>

<script src="{{asset('v2/main.js')}}"></script>

</body>
</html>
