@if(Auth::user()->nom_role == "directeur")                        
<div class="row" style="margin-top: -60px" >
                                            <!--la card Body -->
                                            <!--début de la row-->
    <b>Les performances mensuelles des directions  </b> 
                                                 @php $i= 0; @endphp
                                                @foreach($directions as $direction) 
                                                
                                        
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   <div class="widget-content-left pr-2 fsize-1" >
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">{{intval($action_sum_array_dir[$i])}}%</div>
                                                   </div>
                                                </div>
                                               <div class="widget-content-left fsize-1">
                                                   <div class="perfo-label" style="color:black">{{$direction->nom_direction}}</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                                </div>

                                    @php $i++; @endphp
                                                @endforeach
                                <!--fin de la row-->
                                        <!--fin de la card Body -->
                                
</div>

@elseif(Auth::user()->nom_role == "responsable")
<div class="row" style="margin-top: -80px">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card" style="border-radius : 10px;">
                                    <div class="card-header">
                                        <h3 style="font-family: 'poppins', sans-serif; font-size : 18px; font-weight : bolder; color : black;">La performance mensuelle des membres de mon équipe</h3>
                                        <div class="btn-actions-pane-right"> 
                                        </div>
                                    </div>
                                   
                                    <div class="card-body" >
                                        
                                 
                                    
                               
                                
                                       
                                        <div class="row">
                                        
                                        <?php $age = DB::table('agents')->where('user_id',Auth::user()->id)->first() ?>
                                         <?php $agens = DB::table('agents')->where('direction_id',$age->direction_id)->get() ?>
                                         @php $a = 0; @endphp
                                        @foreach($agent_id as $agent)
                                        
                                            <div class="col-md-6 col-lg-3" >
                                            
                                                <div class="">
                                                    <div class="widget-content card-shadow-dark mb-3 widget-chart widget-chart2 text-left card"style=" height:80px">
                                                   
                                                        <div class="widget-content-outer" >
                                                      
                                                            <div class="widget-content-wrapper">
                                                                <div class="widget-content-top pr-2 fsize-1">
                                                                    
                                                                </div>
                                                                <div class="widget-content-bottom ">
                                                                    <div style="color:black">
                                                                        <b> {{$agent->prenom}} {{$agent->nom}} </b>
                                                                    </div> 
                                                                </div>
                                                                
                                                                <div class="widget-content-wrapper"style="margin-left:30px;">
                                                                    <div class="widget-content-left pr-2 fsize-1">
                                                                        <div class="widget-numbers mt-0 fsize-3 {{ intval($sum_array_agent[$a]) >= 50 ? ' text-black' : 'text-black' }}"><span style="color:#22c8cc">{{intval($sum_array_agent[$a])}}%</span></div>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                
                                           
                                        </div>
                                        @php $a++; @endphp
                                        @endforeach
                                        </div>
                               </div>
                            
                            </div>
                                   
                            </div>
                        </div>
                        
                        
<!--<div class="row">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-header">
                                        <h3 style="font-family: 'poppins', sans-serif; font-size : 18px; font-weight : bolder; color : black;">Membres de mon équipe</h3>
                                        <div class="btn-actions-pane-right"> 
                                        </div>
                                    </div>
                                    <div class="card-body">
                                       
                                        <div class="row">
                                        
                                         <?php $agens = DB::table('agents')->get() ?> 
                                        
                                        </div>
                               </div>
                            
                            </div>
                                   
                            </div>
                        </div>-->
@endif
<style>
    .widget-content{
        
        border: 1px solid transparent;
        border-radius : 10px;
        overflow:hidden;
        
    }
    
    
</style>