@if(Auth::user()->nom_role == "directeur")
<div class="app-page-title">
                           
                           <div class="row">
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                     @php $i= 0;
                                                        $somme_direction = array_sum($sum_array_dir);
                                                     @endphp
                                                   <div class="widget-content-left pr-2 fsize-0" >
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>    {{intval($somme_total_mois)}}% |  <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_total_mois_dir)}}%</span></div>
                                                   </div>
                                                </div>
                                            
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label" style="color:black">CE MOIS</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>     {{intval($ma_semaine_total)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>   <span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">CETTE SEMAINE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black" style="font-family: 'Montserrat', sans-serif; font-size : 12 px;"><i class='fas fa-stop' style='font-size:10px;color:black'></i>    {{intval($ma_semaine_passe)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_semaine_passer_dir)}}%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">LA SEMAINE PASSEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black" style="font-family: 'Montserrat', sans-serif; font-size : 12 px;"><i class='fas fa-stop' style='font-size:10px;color:black'></i>   0% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">0%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">DE L'ANNEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               
                           </div>
                           
                       </div>    
@elseif(Auth::user()->nom_role == "responsable")
<div class="app-page-title">
                           
                           <div class="row">
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                        @php $i= 0;
                                                        $somme_directiossn = array_sum($sum_array_dir);
                                                     @endphp
                                                   <div class="widget-content-left pr-2 fsize-0" >
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>     {{intval($somme_total_mois)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_total_mois_dir)}}%</span></div>
                                                   </div>
                                                </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label" style="color:black">CE MOIS</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>     {{intval($ma_semaine_total)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>     <span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}%</pan></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">CETTE SEMAINE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black" style="font-family: 'Montserrat', sans-serif; font-size : 12 px;"><i class='fas fa-stop' style='font-size:10px;color:black'></i>   {{intval($ma_semaine_passe)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>   <span style="color:#023E8A">{{intval($somme_semaine_passer_dir)}}%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black"> LA SEMAINE PASSEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black" style="font-family: 'Montserrat', sans-serif; font-size : 12 px;"><i class='fas fa-stop' style='font-size:10px;color:black'></i>     0% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">0%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">DE L'ANNEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               
                           </div>
                           
                       </div>    
@elseif(Auth::user()->nom_role == "utilisateur")
                                                   
<div class="app-page-title">
                           <div class="row">
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper"style="color:black">
                                                   @if($actions == " ")
                                                    Pas d'action
                                                    @else
                                                    @if($sum_actions == " ")
                                                    Pas d'action
                                                    @else
                                                     @php $i= 0;
                                                        $somme_directions = array_sum($sum_array_dir);
                                                     @endphp
                                                  <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px'></i>   {{intval($somme_total_mois)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_total_mois_dir)}}% </span></div>
                                                   </div>
                                                @endif
                                                @endif
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">CE MOIS</div>
                                               </div>
                                           </div>
                                       </div>
                                        
                                   </div>
                               </div>
                              
                                
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">      
                                                   @if($action_directions == " ")
                                                    Pas d'action
                                                    @else
                                                    @if($sum_directions == " ")
                                                   Pas d'action
                                                    @else
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>    {{intval($ma_semaine_total)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}% </span></div>
                                                   </div>
                                                @endif
                                                @endif
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">CETTE SEMAINE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">      
                                                   @if($action_directions == " ")
                                                    Pas d'action
                                                    @else
                                                    @if($sum_directions == " ")
                                                   Pas d'action
                                                    @else
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><i class='fas fa-stop' style='font-size:10px;color:black'></i>     {{intval($ma_semaine_passe)}}% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">{{intval($somme_semaine_passer_dir)}}% </span></div>
                                                   </div>
                                                @endif
                                                @endif
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">LA SEMAINE PASSEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-4 col-lg-3">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">
                                                   
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black" style="font-family: 'Montserrat', sans-serif; font-size : 12 px;"><i class='fas fa-stop' style='font-size:10px;color:black'></i>   0% | <i class='fas fa-stop' style='font-size:10px;color:blue'></i>    <span style="color:#023E8A">0%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black"> DE L'ANNEE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>

                                
                               
                           </div>
                           
                       </div> 

@endif


<style>
    .perfo-box{
        background:white;
        border: 1px solid transparent;
        border-radius : 10px;
        
    }
    
    
</style>