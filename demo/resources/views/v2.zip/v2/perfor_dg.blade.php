@if(Auth::user()->nom_role == "directeur")

                           <div class="row">
                              
                               <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">{{intval($ma_semaine_total)}}% </span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">MA PERFORMANCE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               
                               <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style="height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black"><span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}%</span></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">PERFORMANCE DE MA DIRECTION</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               
                               
                           </div>
                           
                         
@elseif(Auth::user()->nom_role == "responsable")

                           <div class="row">
                              
                               <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">     {{intval($ma_semaine_total)}}% </pan></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                           <div class="perfo-label"style="color:black">MA PERFORMANCE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">                               
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">   <span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}%</pan></div>
                                                   </div>
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">PERFORMANCE DE MA DIRECTION</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               
                               
                           </div>
                           
                         
@elseif(Auth::user()->nom_role == "utilisateur")
                                                   
                           <div class="row">
                              <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">      
                                                   @if($action_directions == " ")
                                                    Pas d'action
                                                    @else
                                                    @if($sum_directions == " ")
                                                   Pas d'action
                                                    @else
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">{{intval($ma_semaine_total)}}% </span></div>
                                                   </div>
                                                @endif
                                                @endif
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">MA PERFORMANCE</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <div class="col-md-6 col-lg-4">
                                   <div class="">
                                       <div class="perfo-box card-shadow-primary mb-3 widget-chart widget-chart2 text-left card"style=" height:130px">
                                           <div class="widget-content-outer">
                                               <div class="widget-content-wrapper">      
                                                   @if($action_directions == " ")
                                                    Pas d'action
                                                    @else
                                                    @if($sum_directions == " ")
                                                   Pas d'action
                                                    @else
                                                   <div class="widget-content-left pr-2 fsize-0">
                                                       <div class="widget-numbers mt-0 fsize-3 text-black">   <span style="color:#023E8A">{{intval($somme_total_semaine_dir)}}% </span></div>
                                                   </div>
                                                @endif
                                                @endif
                                               </div>
                                               <div class="widget-content-left fsize-0">
                                                   <div class="perfo-label"style="color:black">PERFORMANCE DE MA DIRECTION</div>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                                
                               </div>
                           </div>
                           
                       

@endif


<style>
    .perfo-box{
        background:white;
        border: 1px solid transparent;
        border-radius : 10px;
        
    }
    
    
</style>