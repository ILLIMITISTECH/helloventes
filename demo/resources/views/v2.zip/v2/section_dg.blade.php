@if(Session::has("success"))
                                            <div class="alert alert-success">
                                            <b>Action clôturée avec succès.</b> 
                                            </div>
                                            @endif
<div class="row">
                            <div class="col-md-12">
                                <h5>@if (session('message'))
                                <div class="alert alert-success alert-dismissible" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    {{ session('message') }}
                                </div>  
                                @endif
                                </h5>
                                <h5>@if (session('cloture'))
                                <div class="alert alert-success alert-dismissible" role="alert">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    {{ session('cloture') }}
                                </div>  
                                @endif
                                </h5>
                                
                                <!-- users -->
                                
                                
                                <!-- end users -->
                              
                               
                                <?php 
                                
                                $user = DB::table('agents')->where('user_id', Auth::user()->id)->first();
            
                                //dd($action_respons);
                                $action_mois = date('m');
                                $action_semaineM7 = (date('d') -7);
                                $action_semaineP7 = (date('d') +7);
                                //$action_responsdff = array();
                                $action_responss = array();
                                $action_bakupss = array();
                                //dd($action_semaineP7);
                                $action_responsf = DB::table('actions')->select('actions.id', 'actions.deadline', 'actions.responsable', 
                                'actions.libelle', 'actions.note',
                                'actions.agent_id','actions.reunion_id','actions.raison',  'actions.visibilite','actions.bakup', 
                                'actions.risque', 'actions.delais','actions.pourcentage', 'actions.note','actions.created_at',
                                'agents.prenom', 'agents.nom', 'agents.photo', 'agents.id as Id','directions.nom_direction'
                                )
                                ->join('agents', 'agents.id', 'actions.agent_id')
                                ->leftjoin('directions', 'directions.id', 'agents.direction_id')
                                ->where('actions.agent_id','=', $user->id)
                               // ->where('actions.bakup','=', $users->full_name)
                                ->orderBy('actions.pourcentage', 'ASC')
                                ->get();
                    
                                foreach($action_responsf as $action_respf)
                                {
                                  
                                    
                                    if(($action_semaineP7 >= date('d', strtotime($action_respf->deadline))) && ($action_semaineM7 <= date('d', strtotime($action_respf->deadline))) && ($action_mois == date('m', strtotime($action_respf->deadline))))
                                    {
                                        array_push($action_responss, $action_respf);
                                        
                                    }
                                }
                                
                                
                                $action_bakupsf = DB::table('actions')->select('actions.id', 'actions.deadline', 'actions.responsable', 
                                'actions.libelle', 'actions.note',
                                'actions.agent_id','actions.reunion_id','actions.raison',  'actions.visibilite','actions.bakup', 
                                'actions.risque', 'actions.delais','actions.pourcentage', 'actions.note','actions.created_at',
                                'agents.prenom', 'agents.nom', 'agents.photo', 'agents.id as Id','directions.nom_direction'
                                )
                                ->join('agents', 'agents.id', 'actions.agent_id')
                                ->leftjoin('directions', 'directions.id', 'agents.direction_id')
                                //->where('actions.agent_id','=', $user->id)
                                ->where('actions.bakup','=', $user->id)
                                ->orderBy('actions.pourcentage', 'ASC')
                                ->get();
                                
                                foreach($action_bakupsf as $action_bakupf)
                                {
                                  
                                    
                                    if(($action_semaineP7 >= date('d', strtotime($action_bakupf->deadline))) && ($action_semaineM7 <= date('d', strtotime($action_bakupf->deadline))) && ($action_mois == date('m', strtotime($action_bakupf->deadline))))
                                    {
                                        array_push($action_bakupss, $action_bakupf);
                                        
                                    }
                                }
                               
                                
                                ?>
                                
                                <div class="main-card mb-3 card">
                                    <div class="card-header" style="font-family: 'Montserrat', sans-serif; font-size : 12 px; font-weight : bolder; color : black;">
                                        
                                        Mes actions en instance de la semaine
                                    </div>
                        
                                        <div class="table-responsive" style="border-radius : 10px;">
                                            
                                            <table class="align-middle mb-0 table table-borderless table-hover">
                                            
                                            <thead>
                                            <tr>
                                                <th class="table-label">Libellé</th>
                                                <th class="table-label">Backup</th>
                                                <th class="text-center">Priorité</th>
                                               <th class="text-center">Progression</th>
                                               
                                                <th class="">Échéance</th>
                                                <th class="">Retard</th>
                                                <th class="">Options</th>
                                            </tr>
                                            </thead>
                                            <tbody >
                                            @foreach($action_responss as $action)  
                                            @if($action->visibilite == 0)
                                            <tr>
                                            <!--<form action="/save_action" method="post" id="target">
                                            <input type="hidden" value="{{csrf_token()}}" name="_token"/>-->
                                                <td class="text-nice">{{$action->libelle}}</td>
                                                @php $agentbackup = DB::table('agents')->where('id', $action->bakup)->first() @endphp
                                                @if($agentbackup)
                                                <td class="text-nice"><span class="responsable">{{substr($agentbackup->prenom, 0, 1)}} {{substr($agentbackup->nom, 0, 1)}}</span></td>
                                                @else
                                                <td class="text-nice"><span class="responsable">--</span></td>
                                                @endif
                                                
                                                @if($action->risque == 'Elevé(E)')
                                                <td class="text-center"><div class="btn btn-danger">Elevé</div></td>
                                                @elseif($action->risque == 'Moins(M)')
                                                <td class="text-center"><div class="btn btn-warning">Moyen</div></td>
                                                @else($action->risque == 'Faible(F)')
                                                <td class="text-center"><div class="btn btn-success">Faible</div></td>
                                                @endif
                                                
                                                 
                                               @if($action->pourcentage > 70)
                                                <td class="text-center"  data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{$action->pourcentage}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;">{{$action->pourcentage}}%</div></td>
                                                @elseif($action->pourcentage >= 50 && $action->pourcentage <= 80)
                                                <td class="text-center"  data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{$action->pourcentage}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;font-weight:bold;">{{$action->pourcentage}}%</div></div></td>
                                                @elseif($action->pourcentage < 50 && $action->pourcentage >= 20)
                                                <td class="text-center" data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="{{$action->pourcentage}}+2" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;font-weight:bold;">{{$action->pourcentage}}%</div></div></td> 
                                                 @elseif($action->pourcentage < 20 && $action->pourcentage >= 10 )
                                                <td class="text-center" data-toggle="tooltip" data-placement="left";{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="{{$action->pourcentage}}+7" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;color:white;font-weight:bold;">{{$action->pourcentage}}%</div></div></td>                                                
                                                @elseif($action->pourcentage < 10)
                                                <td class="text-center" data-toggle="tooltip" data-placement="left" ti;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-default" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;color:black;background:white;">{{$action->pourcentage}}%</div></div></td>
                                              
                                                @endif  
                                             
                                              
                                                <td class="text-nice">{{strftime("%d/%m", strtotime($action->deadline))}}</td>
                                                                    @if($action->deadline < now())
                                                                    <td class="tache text-nice">{{intval(abs(strtotime("now") - strtotime($action->deadline))/ 86400)}} jours</td> 
                                                                    @else
                                                                    <td class="tache text-nice"> Aucun</td>
                                                                    @endif

                                               
                                                
                                                <td class="text-center">
                                                   <div class="student-dtl" style="display:flex; justify-content : space-arround;">
                                                       <span class="d-inline-block" tabindex="0" style="margin-right : 10%;">
                                                            <a id="PopoverCustomT-1" href="{{route('action_user_d.editer', $action->id)}}" type="button" class="btn button-options">
                                                                <i class="fas fa-sync" style="color : black;" data-toggle="tooltip" title="Mettre à jour votre action"></i>
                                                            </a>
                                                        </span>
                                                        <form action="{{route('visibilite.cloture', $action->id)}}" method="post" id="target" class="form">
                                                            <input type="hidden" value="{{csrf_token()}}" name="_token"/>
                                                        @if($action->pourcentage == 100)
                                                         <span class="d-inline-block" tabindex="0">
                                                             <button type="submit" id="PopoverCustomT-1" class="btn btn-primary">
                                                         
                                                            <i class="fas fa-check" style="color : black;" data-toggle="tooltip" title="Cloturer l'action"></i>
                                                            </button>
                                                        </span>
                                                        @else
                                                        <span class="d-inline-block" tabindex="0" disabled>
                                                             <button type="submit" id="PopoverCustomT-1" class="btn boutton-options" disabled>
                                                                <i class="fas fa-check" style="color : black;" data-toggle="tooltip" title="Cloturer l'action" disabled></i>
                                                            </button>
                                                            </span>
                                                        @endif
                                                        </form>
                                                       
                                                    </div>
                                                </td>
                                           
                                            </tr>
                                         @endif
                                            @endforeach
                                            </tbody>
                                        </table>
                                        </div>
                                    
                                </div>
                            
                        

                       <!-- action backup --> 

                       
                                <div class="main-card mb-3 card" >
                                    <div class="card-header" style="font-family: 'Montserrat', sans-serif; font-size : 12 px; font-weight : bolder; color : black;">Les actions de la semaine pour lesquelles je suis Backup
                                    </div>
                                    <div class="table-responsive" style="border-radius : 10px;">
                                        @if(count($action_bakupss) == 0)
                                        
                                        <p>Pas d'actions pour lesquelles je suis Backup</p>
                                        @else
                                         <table class="align-middle mb-0 table table-borderless table-hover">
                                            <thead>
                                            <tr>
                                                <th class="table-label">Libellé</th>
                                                <th class="table-label">Responsable</th>
                                                <th class="text-center">Priorité</th>
                                               <th class="text-center">Progression</th>
                                                
                                                <th class="">Échéance</th>
                                                <th class="">Retard</th>
                                                <th class="">Options</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($action_bakupss as $action)  
                                            
                                             @if($action->visibilite == 0)
                                            <tr>
                                            <!--<form action="/save_action" method="post" id="target">
                                            <input type="hidden" value="{{csrf_token()}}" name="_token"/>-->
                                                <td class="">{{$action->libelle}}</td>
                                                
                                                <td class="text-nice"><span class="responsable">{{substr($action->prenom, 0, 1)}} {{substr($action->nom, 0, 1)}}</span></td>
                                                @if($action->risque == 'Elevé(E)')
                                                <td class="text-center"><div class="btn btn-danger">Elevé</div></td>
                                                @elseif($action->risque == 'Moins(M)')
                                                <td class="text-center"><div class="btn btn-warning">Moyen</div></td>
                                                @else($action->risque == 'Faible(F)')
                                                <td class="text-center"><div class="btn btn-success">Faible</div></td>
                                                @endif
                                                
                                               @if($action->pourcentage > 70)
                                                <td class="text-center"  data-toggle="tooltip" data-placement="left";{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{$action->pourcentage}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;font-weight:bold;">{{$action->pourcentage}}%</div></div></td>
                                                @elseif($action->pourcentage >= 50 && $action->pourcentage <= 80)
                                                <td class="text-center"  data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{$action->pourcentage}}" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;font-weight:bold;">{{$action->pourcentage}}%</div></div></td>
                                                @elseif($action->pourcentage < 50 && $action->pourcentage >= 20)
                                                <td class="text-center" data-toggle="tooltip" data-placement="left";{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="{{$action->pourcentage}}+2" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;font-weight:bold;">{{$action->pourcentage}}%</div></div></td> 
                                                 @elseif($action->pourcentage < 20 && $action->pourcentage >= 10 )
                                                <td class="text-center" data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="{{$action->pourcentage}}+7" aria-valuemin="0" aria-valuemax="100" style="width: {{$action->pourcentage}}%;color:white;font-weight:bold;">{{$action->pourcentage}}%</div></div></td>                                                
                                                @elseif($action->pourcentage < 10)
                                                <td class="text-center" data-toggle="tooltip" data-placement="left" ;{{$action->note}}"><div class="progress" style="height: 15px;"><div class="progress-bar bg-default" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;color:black;background:white;">{{$action->pourcentage}}%</div></div></td>
                                                
                                                @endif  
                                             
                                                
                                                <td class="text-nice">{{strftime("%d/%m", strtotime($action->deadline))}}</td>
                                                                    @if($action->deadline < now())
                                                                    <td class="tache text-nice">{{intval(abs(strtotime("now") - strtotime($action->deadline))/ 86400)}} jours</td> 
                                                                    @else
                                                                    <td class="tache text-nice"> Aucun</td>
                                                                    @endif

                                               
                                                
                                                <td class="text-center">
                                                   <div class="student-dtl" style="display:flex;">
                                                       
                                                       
                                                        <span class="d-inline-block" tabindex="0" style="margin-right : 10%;">
                                                            <a id="PopoverCustomT-1" href="{{route('action_user_d.editer', $action->id)}}" type="button" class="btn boutton-options">
                                                                <i class="fas fa-sync" style="color : black;" data-toggle="tooltip" title="Mettre à jour votre action"></i>
                                                            </a>
                                                        </span>
                                                        <form action="{{route('visibilite.cloture', $action->id)}}" method="post" id="target" class="form">
                                                            <input type="hidden" value="{{csrf_token()}}" name="_token"/>
                                                        @if($action->pourcentage == 100)
                                                       

                                                         <span class="d-inline-block" tabindex="0">
                                                             <button type="submit" id="PopoverCustomT-1" class="btn boutton-options"style="width:17px;>
                                                            <a id="PopoverCustomT-1" href="{{route('action_user_d.editer', $action->id)}}" type="button" class="btn boutton-options">
                                                            <!--    <i class="fas fa-check" style="color : black;" data-toggle="tooltip" title="Cloturer l'action"></i>-->
                                                            <!--</a>-->
                                                            <i class="fas fa-check" style="color : black;margin-left:-10px" data-toggle="tooltip" title="Cloturer l'action"></i>
                                                            </button>
                                                        </span>
                                                        @else
                                                         <span class="d-inline-block" tabindex="0" disabled>
                                                             <button type="submit" id="PopoverCustomT-1" class="btn boutton-options" disabled>
                                                            <!--<a id="PopoverCustomT-1" href="{{route('action_user_d.editer', $action->id)}}" type="button" class="btn boutton-options" disabled>
                                                                <i class="fas fa-check" style="color : black;" data-toggle="tooltip" title="Cloturer l'action" disabled></i>
                                                            </a>-->
                                                            <i class="fas fa-check" style="color : black;margin-left:-10px" data-toggle="tooltip" title="Cloturer l'action" disabled></i>
                                                            </button>
                                                        </span>
                                                        @endif
                                                        </form>
                                                       
                                                    </div>
                                                </td>
                                           
                                            </tr>
                                                @endif
                                            @endforeach
                                            </tbody>
                                        </table>
                                        @endif
                                    </div>
                                    <div class="d-block text-center card-footer">
                                       
                                    </div>
                                </div>
                            
                    </div>
                   </div>
                    <style>

.flip-box {
background-color: transparent;
width: 25px;
height: 25px;
border: 1px solid #f1f1f1;
perspective: 1000px;
}

.flip-box-inner {
position: relative;
width: 100%;
height: 100%;
text-align: center;
transition: transform 0.8s;
transform-style: preserve-3d;
}

.flip-box:hover .flip-box-inner {
transform: rotateY(180deg);
}

.flip-box-front, .flip-box-back {
position: absolute;
width: 100%;
height: 100%;
-webkit-backface-visibility: hidden;
backface-visibility: hidden;
}

.flip-box-front {

color: black;
}

.flip-box-back {
background-color: white;
color: green;
text-align: center;
transform: rotateY(180deg);
}
</style> 

<style>

/* The Modal (background) */
.modal {
display: none; /* Hidden by default */
margin-left: 90px;
margin-top: 150px;
width: 250px; /* Full width */
height: 80px; /* Full height */


}

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding: 20px;
border: 1px solid #888;
width: 100%;
height: 100%;
}

/* The Close Button */
.close {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
}

.close:hover,
.close:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script>
$(document).ready(function(){

@foreach($action_respons as $suivi)

$("#loginVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);  
}
});
}

});

$("#loginnVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginnVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',  
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);
}
});
}

});
@endforeach
});
</script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

<script>
$(document).ready(function(){

@foreach($action_bakups as $suivi)

$("#loginVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);  
}
});
}

});

$("#loginnVisibilite{{$suivi->id}}").change(function(){  
var visibilite = $("#loginnVisibilite{{$suivi->id}}").val();
var suiviID = $("#suiviID{{$suivi->id}}").val()
if(visibilite==""){
alert("please select an option");
}else{
$.ajax({
url: '{{url("/admin/banSuivi")}}',  
data: 'visibilite=' + visibilite + '&suiviID=' + suiviID,
type: 'get',
success:function(response){
console.log(response);
}
});
}

});
@endforeach
});
</script>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>
<style>
  
.popup{
    cursor:pointer;
}

.pop{
    display: none; /* Hidden by default */
    border-radius: 10px;
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 42%;
    top: 30%;
    overflow: auto; /* Enable scroll if needed */
    width: 15%; /* Full width */
     /* Full height */
    padding-top:0px;
    /* Animation ins */
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@keyframes animatetop {
from {top: -300px; opacity: 0}
to {top: 0; opacity: 1}
}
</style>

<script>
// Get the modal
var pop = document.getElementById("pop");

// Get the button that opens the modal
var popup = document.getElementById("popup");

// Get the element that closes the modal
var popclose = document.getElementById("popClose");

popclose.onclick = function(){
    var modal = document.getElementById('modals');
    modal.style.display = "none";
}
// When the user clicks the button, open the modal 
function display() {
    var pop = document.getElementById("pop");
    pop.style.display = "block";
}


// When the user clicks anywhere outside of the popup, close it
window.onclick = function(event) {
if (event.target == pop) {
pop.style.display = "none";
}
}

function check(){
    var radios = document.querySelectorAll('.radios');

    for(var i = 0; i<radios.length; i++){
        if(radios[i].checked.value='O'){
            alert("Bien joué {{Auth::user()->prenom}} 💯 | Action cloturé avec succés." );
        }
    }
}
</script>